// <wtl> project: mtkwlannative | file: abi/25G241/IO80211InfraProtocol.h | author: watchthelight </wtl>
// SPDX-License-Identifier: ISC
// GENERATED from the kcabi dump of 25G241 (macOS 26.7.1 build 25G241, xnu-12377.161.15.700.19~2). Do not edit by hand: re-run genhdr.py.
//
// IO80211InfraProtocol : IO80211InfraInterface as Apple's kernel collection exports it on this build. Slot numbers count the two vtable header words
// (byte offset in the vtable symbol = slot * 8; from a vptr = slot * 8 - 0x10). Instance size 0x130 (MetaClass constructor).
// Names are Apple's own symbols; pure slots are named by the first derived class that implements them. Return types are not
// in mangled names: "ret: guess" is a guess from the name. Checked with genhdr.py check (clang's vtable layout of a probe
// subclass against the dump). Method adapted from ga403wm-hackintosh tools/io80211_abi.py (BSD-3-Clause-Clear).
#pragma once
#include "IO80211InfraInterface.h"
#include <IOKit/IOReturn.h>
#include <stdint.h>

struct ether_addr;
struct __mbuf;
struct appl80211_chip_diags_data;
struct appl80211_sleep_on_inactivity_config;
struct apple80211AssocCandidates;
struct apple80211ChannelInfo;
struct apple80211ScanRequest;
struct apple80211_apmode_data;
struct apple80211_associated_sleep_config;
struct apple80211_battery_ps_config;
struct apple80211_bcn_mute_config;
struct apple80211_beacon_info_t;
struct apple80211_beacon_msg;
struct apple80211_bg_motion_profile;
struct apple80211_bg_network;
struct apple80211_bg_params;
struct apple80211_bg_scan;
struct apple80211_bgscan_cached_network_data_list;
struct apple80211_btcoex_2g_chain_disable;
struct apple80211_btcoex_ext_profile;
struct apple80211_btcoex_max_nss_for_ap_data;
struct apple80211_btcoex_profile;
struct apple80211_btcoex_profile_active_data;
struct apple80211_bypass_tx_power_cap;
struct apple80211_channel_data;
struct apple80211_channels_info;
struct apple80211_chip_power_limit;
struct apple80211_chip_stats;
struct apple80211_congestion_control_indication;
struct apple80211_country_channel_data;
struct apple80211_crash_command;
struct apple80211_dbg_guard_time_params;
struct apple80211_device_accessory_info;
struct apple80211_device_orientation;
struct apple80211_dhcp_renewal_data;
struct apple80211_drbg_entropy;
struct apple80211_dual_power_mode_params;
struct apple80211_dynamic_rssi_window_config;
struct apple80211_dynsar_detail;
struct apple80211_eap_filter_config;
struct apple80211_extended_bss_info;
struct apple80211_facetime_wificalling_params;
struct apple80211_fastlane;
struct apple80211_feature_flags;
struct apple80211_fw_clock_info;
struct apple80211_fw_clock_source;
struct apple80211_fw_hot_channels;
struct apple80211_gas_query_t;
struct apple80211_guard_interval_data;
struct apple80211_he_capability;
struct apple80211_he_counters_ctl;
struct apple80211_host_clock_info;
struct apple80211_hp2p_ctrl;
struct apple80211_ht_capability;
struct apple80211_hw_mac_address;
struct apple80211_ie_data;
struct apple80211_infra_enumerated;
struct apple80211_interface_setting;
struct apple80211_ipv4_params;
struct apple80211_ipv6_params;
struct apple80211_key;
struct apple80211_le_scan_params;
struct apple80211_leaky_ap_setting;
struct apple80211_leave_network;
struct apple80211_legacy_roam_profile_config;
struct apple80211_limited_aggregation_config;
struct apple80211_lmtpc_config;
struct apple80211_low_latency_info;
struct apple80211_lqm_config_t;
struct apple80211_lqm_statistics;
struct apple80211_lqm_summary;
struct apple80211_mcs_data;
struct apple80211_mcs_vht_data;
struct apple80211_mimo_config;
struct apple80211_mimo_status;
struct apple80211_mitigate_interference;
struct apple80211_mws_accessory_power_limit;
struct apple80211_mws_antenna_selection;
struct apple80211_mws_condition_id_config;
struct apple80211_mws_rfem_config;
struct apple80211_mws_scan_freq;
struct apple80211_mws_scan_freq_mode;
struct apple80211_mws_time_sharing;
struct apple80211_mws_wifi_channel_bitmap;
struct apple80211_ndd_data;
struct apple80211_network_data;
struct apple80211_noise_per_ant_t;
struct apple80211_nss_data;
struct apple80211_offload_arp_data;
struct apple80211_offload_ndp_data;
struct apple80211_offload_tcpka_enable_t;
struct apple80211_opmode_data;
struct apple80211_os_eligibility;
struct apple80211_p2p_device_capability;
struct apple80211_pm_mode;
struct apple80211_pmk;
struct apple80211_power_budget_t;
struct apple80211_power_debug_info;
struct apple80211_power_profile;
struct apple80211_powersave_data;
struct apple80211_powertable_version_data;
struct apple80211_private_mac_data;
struct apple80211_ranging_authenticate_request_t;
struct apple80211_ranging_capabilities_t;
struct apple80211_ranging_enable_request_t;
struct apple80211_ranging_start_request_t;
struct apple80211_rate_data;
struct apple80211_reassoc;
struct apple80211_reset_command;
struct apple80211_roam_cache_data;
struct apple80211_roam_profile_all_bands;
struct apple80211_roam_profile_config;
struct apple80211_rsdb_capability;
struct apple80211_rsn_xe_data;
struct apple80211_rssi_data;
struct apple80211_sdb_enable;
struct apple80211_sensing_data_t;
struct apple80211_sensing_disable_t;
struct apple80211_sensing_enable_t;
struct apple80211_set_property_unserialized_data;
struct apple80211_set_roam_lock;
struct apple80211_sib_coex_status;
struct apple80211_slow_wifi_feature_enabled;
struct apple80211_smartcca_opmode;
struct apple80211_standalone_state;
struct apple80211_state_data;
struct apple80211_sup_channel_data;
struct apple80211_system_sleep_config;
struct apple80211_thermal_index_t;
struct apple80211_timestamping_en;
struct apple80211_timesync_gpio;
struct apple80211_timesync_info;
struct apple80211_timesync_rx_policy;
struct apple80211_timesync_stats;
struct apple80211_timesync_tx_policy;
struct apple80211_tko_dump;
struct apple80211_tko_params;
struct apple80211_traffic_eng_params;
struct apple80211_trap_info_data;
struct apple80211_trap_mini_dump_data;
struct apple80211_tx_mode_config;
struct apple80211_txpower_data;
struct apple80211_txrx_chain_info;
struct apple80211_usb_host_notification_data;
struct apple80211_user_roam_cache;
struct apple80211_vht_capability;
struct apple80211_virt_if_create_data;
struct apple80211_voice_ind_state;
struct apple80211_wcl_abort_join;
struct apple80211_wcl_action_frame;
struct apple80211_wcl_arp_mode;
struct apple80211_wcl_low_latency_stats;
struct apple80211_wcl_qos_params;
struct apple80211_wcl_real_time_mode;
struct apple80211_wcl_traffic_counters;
struct apple80211_wcl_ulofdma_state;
struct apple80211_wcl_wnm_config_t;
struct apple80211_wcl_wnm_offload_t;
struct apple80211_wifi_assertion_data;
struct apple80211_wow_low_power_mode;
struct apple80211_wow_test_data;
struct bss_blacklist;
struct mloAddrArray;
struct scanHomeAndAwayTime;
struct triggerCC;

class IO80211InfraProtocol : public IO80211InfraInterface {
    OSDeclareAbstractStructors(IO80211InfraProtocol)

public:

    // new virtuals, slots 470..669
    /* 470 */ virtual IOReturn setMacAddress(mloAddrArray& a1) = 0;   // ret: Apple's interface returns its core's status
    /* 471 */ virtual IOReturn getCHANNEL(apple80211_channel_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 472 */ virtual IOReturn getPOWERSAVE(apple80211_powersave_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 473 */ virtual IOReturn getTXPOWER(apple80211_txpower_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 474 */ virtual IOReturn getRATE(apple80211_rate_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 475 */ virtual IOReturn getOP_MODE(apple80211_opmode_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 476 */ virtual IOReturn getRSSI(apple80211_rssi_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 477 */ virtual IOReturn getSUPPORTED_CHANNELS(apple80211_sup_channel_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 478 */ virtual IOReturn getGUARD_INTERVAL(apple80211_guard_interval_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 479 */ virtual IOReturn getMCS(apple80211_mcs_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 480 */ virtual IOReturn getPOWER_DEBUG_INFO(apple80211_power_debug_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 481 */ virtual IOReturn getHT_CAPABILITY(apple80211_ht_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 482 */ virtual IOReturn getMCS_VHT(apple80211_mcs_vht_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 483 */ virtual IOReturn getCHANNELS_INFO(apple80211_channels_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 484 */ virtual IOReturn getVHT_CAPABILITY(apple80211_vht_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 485 */ virtual IOReturn getROAM_PROFILE(apple80211_roam_profile_all_bands* a1) = 0;   // ret: request handler: the ioctl status
    /* 486 */ virtual IOReturn getCHIP_COUNTER_STATS(apple80211_chip_stats* a1) = 0;   // ret: request handler: the ioctl status
    /* 487 */ virtual IOReturn getDBG_GUARD_TIME_PARAMS(apple80211_dbg_guard_time_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 488 */ virtual IOReturn getLEAKY_AP_STATS_MODE(apple80211_leaky_ap_setting* a1) = 0;   // ret: request handler: the ioctl status
    /* 489 */ virtual IOReturn getCOUNTRY_CHANNELS(apple80211_country_channel_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 490 */ virtual IOReturn getPRIVATE_MAC(apple80211_private_mac_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 491 */ virtual IOReturn getRANGING_ENABLE(apple80211_ranging_enable_request_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 492 */ virtual IOReturn getRANGING_START(apple80211_ranging_start_request_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 493 */ virtual IOReturn getAWDL_RSDB_CAPS(apple80211_rsdb_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 494 */ virtual IOReturn getTKO_PARAMS(apple80211_tko_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 495 */ virtual IOReturn getTKO_DUMP(apple80211_tko_dump* a1) = 0;   // ret: request handler: the ioctl status
    /* 496 */ virtual IOReturn getHW_SUPPORTED_CHANNELS(apple80211_sup_channel_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 497 */ virtual IOReturn getBTCOEX_PROFILE(apple80211_btcoex_profile* a1) = 0;   // ret: request handler: the ioctl status
    /* 498 */ virtual IOReturn getBTCOEX_PROFILE_ACTIVE(apple80211_btcoex_profile_active_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 499 */ virtual IOReturn getTRAP_INFO(apple80211_trap_info_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 500 */ virtual IOReturn getTHERMAL_INDEX(apple80211_thermal_index_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 501 */ virtual IOReturn getMAX_NSS_FOR_AP(apple80211_btcoex_max_nss_for_ap_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 502 */ virtual IOReturn getBTCOEX_2G_CHAIN_DISABLE(apple80211_btcoex_2g_chain_disable* a1) = 0;   // ret: request handler: the ioctl status
    /* 503 */ virtual IOReturn getPOWER_BUDGET(apple80211_power_budget_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 504 */ virtual IOReturn getOFFLOAD_TCPKA_ENABLE(apple80211_offload_tcpka_enable_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 505 */ virtual IOReturn getRANGING_CAPS(apple80211_ranging_capabilities_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 506 */ virtual IOReturn getLQM_CONFIG(apple80211_lqm_config_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 507 */ virtual IOReturn getTRAP_CRASHTRACER_MINI_DUMP(apple80211_trap_mini_dump_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 508 */ virtual IOReturn getBEACON_INFO(apple80211_beacon_info_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 509 */ virtual IOReturn getCHIP_POWER_RANGE(apple80211_chip_power_limit* a1) = 0;   // ret: request handler: the ioctl status
    /* 510 */ virtual IOReturn getNSS(apple80211_nss_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 511 */ virtual IOReturn getHW_ADDR(apple80211_hw_mac_address* a1) = 0;   // ret: request handler: the ioctl status
    /* 512 */ virtual IOReturn getCHIP_DIAGS(appl80211_chip_diags_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 513 */ virtual IOReturn getHP2P_CTRL(apple80211_hp2p_ctrl* a1) = 0;   // ret: request handler: the ioctl status
    /* 514 */ virtual IOReturn getBSS_BLACKLIST(bss_blacklist* a1) = 0;   // ret: request handler: the ioctl status
    /* 515 */ virtual IOReturn getTXRX_CHAIN_INFO(apple80211_txrx_chain_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 516 */ virtual IOReturn getMIMO_STATUS(apple80211_mimo_status* a1) = 0;   // ret: request handler: the ioctl status
    /* 517 */ virtual IOReturn getCUR_PMK(apple80211_pmk* a1) = 0;   // ret: request handler: the ioctl status
    /* 518 */ virtual IOReturn getDYNSAR_DETAIL(apple80211_dynsar_detail* a1) = 0;   // ret: request handler: the ioctl status
    /* 519 */ virtual IOReturn getCOUNTRY_CHANNELS_INFO(apple80211_channels_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 520 */ virtual IOReturn getLQM_SUMMARY(apple80211_lqm_summary* a1) = 0;   // ret: request handler: the ioctl status
    /* 521 */ virtual IOReturn getSLOW_WIFI_FEATURE_ENABLED(apple80211_slow_wifi_feature_enabled* a1) = 0;   // ret: request handler: the ioctl status
    /* 522 */ virtual IOReturn getTIMESYNC_INFO(apple80211_timesync_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 523 */ virtual IOReturn getSENSING_DATA(apple80211_sensing_data_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 524 */ virtual IOReturn getWCL_FW_HOT_CHANNELS(apple80211_fw_hot_channels* a1) = 0;   // ret: request handler: the ioctl status
    /* 525 */ virtual IOReturn getWCL_LOW_LATENCY_INFO(apple80211_low_latency_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 526 */ virtual IOReturn getWCL_BSS_INFO(apple80211_beacon_msg* a1) = 0;   // ret: request handler: the ioctl status
    /* 527 */ virtual IOReturn getWCL_TRAFFIC_COUNTERS(apple80211_wcl_traffic_counters* a1) = 0;   // ret: request handler: the ioctl status
    /* 528 */ virtual IOReturn getWCL_GET_TX_BLANKING_STATUS(uint32_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 529 */ virtual IOReturn getHE_COUNTERS(apple80211_he_counters_ctl* a1) = 0;   // ret: request handler: the ioctl status
    /* 530 */ virtual IOReturn getWCL_CHANNELS_INFO(apple80211ChannelInfo* a1) = 0;   // ret: request handler: the ioctl status
    /* 531 */ virtual IOReturn getRSN_XE(apple80211_rsn_xe_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 532 */ virtual IOReturn getSIB_COEX_STATUS(apple80211_sib_coex_status* a1) = 0;   // ret: request handler: the ioctl status
    /* 533 */ virtual IOReturn getWCL_EXTENDED_BSS_INFO(apple80211_extended_bss_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 534 */ virtual IOReturn getWCL_LOW_LATENCY_INFO_STATS(apple80211_wcl_low_latency_stats* a1) = 0;   // ret: request handler: the ioctl status
    /* 535 */ virtual IOReturn getWCL_BGSCAN_CACHE_RESULT(apple80211_bgscan_cached_network_data_list* a1) = 0;   // ret: request handler: the ioctl status
    /* 536 */ virtual IOReturn getWCL_WNM_OFFLOAD(apple80211_wcl_wnm_offload_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 537 */ virtual IOReturn getWIFI_NOISE_PER_ANT(apple80211_noise_per_ant_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 538 */ virtual IOReturn getFW_CLOCK_INFO(apple80211_fw_clock_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 539 */ virtual IOReturn getTIMESYNC_STATS(apple80211_timesync_stats* a1) = 0;   // ret: request handler: the ioctl status
    /* 540 */ virtual IOReturn getSYSTEM_SLEEP_CONFIG(apple80211_system_sleep_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 541 */ virtual IOReturn getSMARTCCA_OPMODE(apple80211_smartcca_opmode* a1) = 0;   // ret: request handler: the ioctl status
    /* 542 */ virtual IOReturn getLQM_STATISTICS(apple80211_lqm_statistics* a1) = 0;   // ret: request handler: the ioctl status
    /* 543 */ virtual IOReturn getHE_CAPABILITY(apple80211_he_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 544 */ virtual IOReturn getDEVICE_ORIENTATION(apple80211_device_orientation* a1) = 0;   // ret: request handler: the ioctl status
    /* 545 */ virtual IOReturn getACCESSORY_STATE(apple80211_device_accessory_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 546 */ virtual IOReturn getP2P_DEVICE_CAPABILITY(apple80211_p2p_device_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 547 */ virtual IOReturn getPOWERTABLE_VERSION(apple80211_powertable_version_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 548 */ virtual IOReturn setCIPHER_KEY(apple80211_key* a1) = 0;   // ret: request handler: the ioctl status
    /* 549 */ virtual IOReturn setCHANNEL(apple80211_channel_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 550 */ virtual IOReturn setPOWERSAVE(apple80211_powersave_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 551 */ virtual IOReturn setTXPOWER(apple80211_txpower_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 552 */ virtual IOReturn setRATE(apple80211_rate_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 553 */ virtual IOReturn setIBSS_MODE(apple80211_network_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 554 */ virtual IOReturn setAP_MODE(apple80211_apmode_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 555 */ virtual IOReturn setIE(apple80211_ie_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 556 */ virtual IOReturn setWOW_TEST(apple80211_wow_test_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 557 */ virtual IOReturn setCLEAR_PMKSA_CACHE(void* a1) = 0;   // ret: request handler: the ioctl status
    /* 558 */ virtual IOReturn setVIRTUAL_IF_CREATE(apple80211_virt_if_create_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 559 */ virtual IOReturn setHT_CAPABILITY(apple80211_ht_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 560 */ virtual IOReturn setOFFLOAD_ARP(apple80211_offload_arp_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 561 */ virtual IOReturn setOFFLOAD_NDP(apple80211_offload_ndp_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 562 */ virtual IOReturn setGAS_REQ(apple80211_gas_query_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 563 */ virtual IOReturn setVHT_CAPABILITY(apple80211_vht_capability* a1) = 0;   // ret: request handler: the ioctl status
    /* 564 */ virtual IOReturn setROAM_PROFILE(apple80211_roam_profile_all_bands* a1) = 0;   // ret: request handler: the ioctl status
    /* 565 */ virtual IOReturn setDBG_GUARD_TIME_PARAMS(apple80211_dbg_guard_time_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 566 */ virtual IOReturn setLEAKY_AP_STATS_MODE(apple80211_leaky_ap_setting* a1) = 0;   // ret: request handler: the ioctl status
    /* 567 */ virtual IOReturn setPRIVATE_MAC(apple80211_private_mac_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 568 */ virtual IOReturn setRESET_CHIP(apple80211_reset_command* a1) = 0;   // ret: request handler: the ioctl status
    /* 569 */ virtual IOReturn setCRASH(apple80211_crash_command* a1) = 0;   // ret: request handler: the ioctl status
    /* 570 */ virtual IOReturn setRANGING_ENABLE(apple80211_ranging_enable_request_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 571 */ virtual IOReturn setRANGING_START(apple80211_ranging_start_request_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 572 */ virtual IOReturn setRANGING_AUTHENTICATE(apple80211_ranging_authenticate_request_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 573 */ virtual IOReturn setTKO_PARAMS(apple80211_tko_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 574 */ virtual IOReturn setBTCOEX_PROFILE(apple80211_btcoex_profile* a1) = 0;   // ret: request handler: the ioctl status
    /* 575 */ virtual IOReturn setBTCOEX_PROFILE_ACTIVE(apple80211_btcoex_profile_active_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 576 */ virtual IOReturn setTHERMAL_INDEX(apple80211_thermal_index_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 577 */ virtual IOReturn setBTCOEX_2G_CHAIN_DISABLE(apple80211_btcoex_2g_chain_disable* a1) = 0;   // ret: request handler: the ioctl status
    /* 578 */ virtual IOReturn setPOWER_BUDGET(apple80211_power_budget_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 579 */ virtual IOReturn setOFFLOAD_TCPKA_ENABLE(apple80211_offload_tcpka_enable_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 580 */ virtual IOReturn setLQM_CONFIG(apple80211_lqm_config_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 581 */ virtual IOReturn setDYNAMIC_RSSI_WINDOW_CONFIG(apple80211_dynamic_rssi_window_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 582 */ virtual IOReturn setUSB_HOST_NOTIFICATION(apple80211_usb_host_notification_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 583 */ virtual IOReturn setHP2P_CTRL(apple80211_hp2p_ctrl* a1) = 0;   // ret: request handler: the ioctl status
    /* 584 */ virtual IOReturn setBSS_BLACKLIST(bss_blacklist* a1) = 0;   // ret: request handler: the ioctl status
    /* 585 */ virtual IOReturn setSET_PROPERTY(apple80211_set_property_unserialized_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 586 */ virtual IOReturn setROAM_CACHE_UPDATE(apple80211_roam_cache_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 587 */ virtual IOReturn setPM_MODE(apple80211_pm_mode* a1) = 0;   // ret: request handler: the ioctl status
    /* 588 */ virtual IOReturn setSET_WIFI_ASSERTION_STATE(apple80211_wifi_assertion_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 589 */ virtual IOReturn setREALTIME_QOS_MSCS(apple80211_state_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 590 */ virtual IOReturn setSENSING_ENABLE(apple80211_sensing_enable_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 591 */ virtual IOReturn setSENSING_DISABLE(apple80211_sensing_disable_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 592 */ virtual IOReturn setWCL_LEAVE_NETWORK(apple80211_leave_network* a1) = 0;   // ret: request handler: the ioctl status
    /* 593 */ virtual IOReturn setWCL_REASSOC(apple80211_reassoc* a1) = 0;   // ret: request handler: the ioctl status
    /* 594 */ virtual IOReturn setWCL_SET_ROAM_LOCK(apple80211_set_roam_lock* a1) = 0;   // ret: request handler: the ioctl status
    /* 595 */ virtual IOReturn setWCL_LEGACY_ROAM_PROFILE_CONFIG(apple80211_legacy_roam_profile_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 596 */ virtual IOReturn setWCL_ROAM_PROFILE_CONFIG(apple80211_roam_profile_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 597 */ virtual IOReturn setWCL_ROAM_USER_CACHE(apple80211_user_roam_cache* a1) = 0;   // ret: request handler: the ioctl status
    /* 598 */ virtual IOReturn setWCL_SCAN_ABORT(void* a1) = 0;   // ret: request handler: the ioctl status
    /* 599 */ virtual IOReturn setWCL_REAL_TIME_MODE(apple80211_wcl_real_time_mode* a1) = 0;   // ret: request handler: the ioctl status
    /* 600 */ virtual IOReturn setWCL_ARP_MODE(apple80211_wcl_arp_mode* a1) = 0;   // ret: request handler: the ioctl status
    /* 601 */ virtual IOReturn setWCL_JOIN_ABORT(apple80211_wcl_abort_join* a1) = 0;   // ret: request handler: the ioctl status
    /* 602 */ virtual IOReturn setWCL_TRIGGER_CC(triggerCC* a1) = 0;   // ret: request handler: the ioctl status
    /* 603 */ virtual IOReturn setWCL_SCAN_REQ(apple80211ScanRequest* a1) = 0;   // ret: request handler: the ioctl status
    /* 604 */ virtual IOReturn setWCL_ASSOCIATE(apple80211AssocCandidates* a1) = 0;   // ret: request handler: the ioctl status
    /* 605 */ virtual IOReturn setWCL_QOS_PARAMS(apple80211_wcl_qos_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 606 */ virtual IOReturn setWCL_LINK_UP_DONE(void* a1) = 0;   // ret: request handler: the ioctl status
    /* 607 */ virtual IOReturn setWCL_SET_SCAN_HOME_AWAY_TIME(scanHomeAndAwayTime* a1) = 0;   // ret: request handler: the ioctl status
    /* 608 */ virtual IOReturn setVOICE_IND_STATE(apple80211_voice_ind_state* a1) = 0;   // ret: request handler: the ioctl status
    /* 609 */ virtual IOReturn setRSN_XE(apple80211_rsn_xe_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 610 */ virtual IOReturn setMWS_ACCESSORY_POWER_LIMIT_WIFI_ENH(apple80211_mws_accessory_power_limit* a1) = 0;   // ret: request handler: the ioctl status
    /* 611 */ virtual IOReturn setWCL_ULOFDMA_STATE(apple80211_wcl_ulofdma_state* a1) = 0;   // ret: request handler: the ioctl status
    /* 612 */ virtual IOReturn setWCL_ACTION_FRAME(apple80211_wcl_action_frame* a1) = 0;   // ret: request handler: the ioctl status
    /* 613 */ virtual IOReturn setGAS_ABORT(void* a1) = 0;   // ret: request handler: the ioctl status
    /* 614 */ virtual IOReturn setOS_FEATURE_FLAGS(apple80211_feature_flags* a1) = 0;   // ret: request handler: the ioctl status
    /* 615 */ virtual IOReturn setDHCP_RENEWAL_DATA(apple80211_dhcp_renewal_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 616 */ virtual IOReturn setBATTERY_POWERSAVE_CONFIG(apple80211_battery_ps_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 617 */ virtual IOReturn setMIMO_CONFIG(apple80211_mimo_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 618 */ virtual IOReturn setWCL_CONFIG_BG_MOTIONPROFILE(apple80211_bg_motion_profile* a1) = 0;   // ret: request handler: the ioctl status
    /* 619 */ virtual IOReturn setWCL_CONFIG_BG_NETWORK(apple80211_bg_network* a1) = 0;   // ret: request handler: the ioctl status
    /* 620 */ virtual IOReturn setWCL_CONFIG_BGSCAN(apple80211_bg_scan* a1) = 0;   // ret: request handler: the ioctl status
    /* 621 */ virtual IOReturn setWCL_CONFIG_BG_PARAMS(apple80211_bg_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 622 */ virtual IOReturn setPOWER_PROFILE(apple80211_power_profile* a1) = 0;   // ret: request handler: the ioctl status
    /* 623 */ virtual IOReturn setHEARTBEAT(void* a1) = 0;   // ret: request handler: the ioctl status
    /* 624 */ virtual IOReturn setINTERFACE_SETTING(apple80211_interface_setting* a1) = 0;   // ret: request handler: the ioctl status
    /* 625 */ virtual IOReturn setBYPASS_TX_POWER_CAP(apple80211_bypass_tx_power_cap* a1) = 0;   // ret: request handler: the ioctl status
    /* 626 */ virtual IOReturn setFACETIME_WIFICALLING_PARAMS(apple80211_facetime_wificalling_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 627 */ virtual IOReturn setIPV4_PARAMS(apple80211_ipv4_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 628 */ virtual IOReturn setWCL_WNM_OPS(apple80211_wcl_wnm_config_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 629 */ virtual IOReturn setWCL_WNM_OFFLOAD(apple80211_wcl_wnm_offload_t* a1) = 0;   // ret: request handler: the ioctl status
    /* 630 */ virtual IOReturn setWCL_LIMITED_AGGREGATION(apple80211_limited_aggregation_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 631 */ virtual IOReturn setWCL_BCN_MUTE_CONFIG(apple80211_bcn_mute_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 632 */ virtual IOReturn setEAP_FILTER_CONFIG(apple80211_eap_filter_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 633 */ virtual IOReturn setWOW_LOW_POWER_MODE(apple80211_wow_low_power_mode* a1) = 0;   // ret: request handler: the ioctl status
    /* 634 */ virtual IOReturn setDUAL_POWER_MODE(apple80211_dual_power_mode_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 635 */ virtual IOReturn setWCL_UPDATE_FAST_LANE(apple80211_fastlane* a1) = 0;   // ret: request handler: the ioctl status
    /* 636 */ virtual IOReturn setWCL_ASSOCIATED_SLEEP(apple80211_associated_sleep_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 637 */ virtual IOReturn setCONGESTION_CTRL_IND(apple80211_congestion_control_indication* a1) = 0;   // ret: request handler: the ioctl status
    /* 638 */ virtual IOReturn setSTAND_ALONE_MODE_STATE(apple80211_standalone_state* a1) = 0;   // ret: request handler: the ioctl status
    /* 639 */ virtual IOReturn setIPV6_PARAMS(apple80211_ipv6_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 640 */ virtual IOReturn setINFRA_ENUMERATED(apple80211_infra_enumerated* a1) = 0;   // ret: request handler: the ioctl status
    /* 641 */ virtual IOReturn setLMTPC_CONFIG(apple80211_lmtpc_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 642 */ virtual IOReturn setTRAFFIC_ENG_PARAMS(apple80211_traffic_eng_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 643 */ virtual IOReturn setLE_SCAN_PARAM(apple80211_le_scan_params* a1) = 0;   // ret: request handler: the ioctl status
    /* 644 */ virtual IOReturn setTIMESYNC_GPIO(apple80211_timesync_gpio* a1) = 0;   // ret: request handler: the ioctl status
    /* 645 */ virtual IOReturn setHOST_CLOCK_INFO(apple80211_host_clock_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 646 */ virtual IOReturn setFW_CLOCK_SOURCE(apple80211_fw_clock_source* a1) = 0;   // ret: request handler: the ioctl status
    /* 647 */ virtual IOReturn setTIMESYNC_TX_POLICY(apple80211_timesync_tx_policy* a1) = 0;   // ret: request handler: the ioctl status
    /* 648 */ virtual IOReturn setTIMESYNC_RX_POLICY(apple80211_timesync_rx_policy* a1) = 0;   // ret: request handler: the ioctl status
    /* 649 */ virtual IOReturn setTIMESTAMPING_EN(apple80211_timestamping_en* a1) = 0;   // ret: request handler: the ioctl status
    /* 650 */ virtual IOReturn setWCL_SOI_CONFIG(appl80211_sleep_on_inactivity_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 651 */ virtual IOReturn setMWS_TIME_SHARING_WIFI_ENH(apple80211_mws_time_sharing* a1) = 0;   // ret: request handler: the ioctl status
    /* 652 */ virtual IOReturn setMWS_WIFI_TYPE_7_BITMAP_WIFI_ENH(apple80211_mws_wifi_channel_bitmap* a1) = 0;   // ret: request handler: the ioctl status
    /* 653 */ virtual IOReturn setMWS_COEX_BITMAP_WIFI_ENH(apple80211_mws_wifi_channel_bitmap* a1) = 0;   // ret: request handler: the ioctl status
    /* 654 */ virtual IOReturn setMWS_DISABLE_OCL_BITMAP_WIFI_ENH(apple80211_mws_wifi_channel_bitmap* a1) = 0;   // ret: request handler: the ioctl status
    /* 655 */ virtual IOReturn setMWS_RFEM_CONFIG_WIFI_ENH(apple80211_mws_rfem_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 656 */ virtual IOReturn setMWS_ASSOC_PROTECTION_BITMAP_WIFI_ENH(apple80211_mws_wifi_channel_bitmap* a1) = 0;   // ret: request handler: the ioctl status
    /* 657 */ virtual IOReturn setMWS_SCAN_FREQ_WIFI_ENH(apple80211_mws_scan_freq* a1) = 0;   // ret: request handler: the ioctl status
    /* 658 */ virtual IOReturn setMWS_SCAN_FREQ_MODE_WIFI_ENH(apple80211_mws_scan_freq_mode* a1) = 0;   // ret: request handler: the ioctl status
    /* 659 */ virtual IOReturn setMWS_CONDITION_ID_BITMAP_WIFI_ENH(apple80211_mws_condition_id_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 660 */ virtual IOReturn setMWS_ANTENNA_SELECTION_WIFI_ENH(apple80211_mws_antenna_selection* a1) = 0;   // ret: request handler: the ioctl status
    /* 661 */ virtual IOReturn setNDD_REQ(apple80211_ndd_data* a1) = 0;   // ret: request handler: the ioctl status
    /* 662 */ virtual IOReturn setDBRG_ENTROPY(apple80211_drbg_entropy* a1) = 0;   // ret: request handler: the ioctl status
    /* 663 */ virtual IOReturn setSDB_ENABLE(apple80211_sdb_enable* a1) = 0;   // ret: request handler: the ioctl status
    /* 664 */ virtual IOReturn setBTCOEX_EXT_PROFILE(apple80211_btcoex_ext_profile* a1) = 0;   // ret: request handler: the ioctl status
    /* 665 */ virtual IOReturn setDEVICE_ORIENTATION(apple80211_device_orientation* a1) = 0;   // ret: request handler: the ioctl status
    /* 666 */ virtual IOReturn setACCESSORY_STATE(apple80211_device_accessory_info* a1) = 0;   // ret: request handler: the ioctl status
    /* 667 */ virtual IOReturn setOS_ELIGIBILITY(apple80211_os_eligibility* a1) = 0;   // ret: request handler: the ioctl status
    /* 668 */ virtual IOReturn setTX_MODE_CONFIG(apple80211_tx_mode_config* a1) = 0;   // ret: request handler: the ioctl status
    /* 669 */ virtual IOReturn setMITIGATE_INTERFERENCE(apple80211_mitigate_interference* a1) = 0;   // ret: request handler: the ioctl status

};
static_assert(sizeof(IO80211InfraProtocol) == 0x130, "IO80211InfraProtocol must be 0x130 bytes (25G241)");
